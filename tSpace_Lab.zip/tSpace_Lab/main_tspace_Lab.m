% Load files
% tspace interface for calculation

clear
% get current path
[curr_path, ~, ~] = fileparts(mfilename('fullpath'));
curr_path = [curr_path filesep];

% get all subdirectories
path_with_subdirectories = genpath(curr_path );
addpath( path_with_subdirectories );
savepath;
currentfolder = '';
allfiles = uipickfiles('num',[1 inf],'out','cell', 'FilterSpec', currentfolder, 'REFilter', '\.csv$');
if isequal(allfiles,0) ~=0
   return 
end
    
[~, ~, exts] = cellfun(@fileparts, allfiles, 'UniformOutput', false);
[uexts, IA, IC] = unique(exts);

% Before any transforamation is done, select what you want to calculate

for i=1:numel(uexts) %load csv file
    files = allfiles(IC==i);
        
    [path, ~, ext] = fileparts(files{1});
    %Read in header
    fids = cellfun(@(f) fopen(f, 'r'), files, 'UniformOutput', false);  %opening files
    csvheaders = cellfun(@(f) fgetl(f), fids, 'UniformOutput', false);   %readinf first line in file
    cellfun(@(f) fclose(f), fids, 'UniformOutput', false);  %closing files

    % Convert  header to cell array
    csvheaders = cellfun(@(h) regexp(h, '([^,]*)', 'tokens'), csvheaders, 'UniformOutput', false);
    csvheaders = cellfun(@(h) cat(2, h{:}), csvheaders, 'UniformOutput', false);
    
    % skip empty columns, index, time, beads, and cell or event length columns
    hdrs = csvheaders{1};
    omit = {'""', '', '"index"','index','"Time"','Time','"Cell_length"', 'Cell_length', '"Event_length"', 'Event_length', 'beads', '"beads"', 'Beads', '"Beads"'};
    %Indices of columns to be removed 
    Colindex = [find(ismember(hdrs,omit)), find(~cellfun(@isempty,regexpi(hdrs,'barcod')))];
    csvdats = cellfun(@(fname) csvread(fname, 1, 0), files, 'UniformOutput', false);
    csvdats = csvdats{i};
    
     if (input('If your file contains multiple samples labeled in specific column, press 1; otherwise press 0:'))
        prompt = sprintf('Type in the name of the column that labels samples: ');
        str = input(prompt, 's');
        SampleInd = find(~cellfun(@isempty,regexpi(hdrs,str)));
            if(find(SampleInd))
            disp('Column successfully found')
            Colindex = [Colindex, SampleInd];
            %Save Sample column
            Sample = csvdats(:,SampleInd);
            else
            disp('Check your column names and repeat loading of files')
            end   
    end
    
    
    csvdats(:,Colindex)=[];
    
    hdrs(:,Colindex)=[];
    
    dataType = input('Press \n[1] for CyTOF/FACS Data or \n[2] scRNAseq: ');
    if (dataType ==1)
        if (input('To transform data, press 1 \n if you have transformed data, press 0: '))
        transType = input('Press \n[1] for CyTOF Data (arcsinh) or \n[2] FACS Data (logicle, be patient): ');
            if (transType ==1)
            %CyTOF data transformation with arcsin
                csvdats = asinh(csvdats./5);
            elseif (transType == 2)
            %FACS data transformation with LOGICLE transformation
            %It takes into account minimum value of each channel
                parfor (p = 1:size(csvdats,2),feature('numCores'))
                    w = (4.5-log10(262144/abs(min(csvdats(:,p)))))/2;
                    if w < 0
                        obj = [LogicleTransform(262144,0.5,4.5,0)];
                        csvdats(:,p) = obj.transform(csvdats(:,p));
                    else 
                        obj = [LogicleTransform(262144,w,4.5,0)];
                        csvdats(:,p) = obj.transform(csvdats(:,p));
                    end
                end 
            end
        end
        csvdats_rem = csvdats;
        hdrs_rem=hdrs;    
        removed = 0;
        for j = 1:numel(hdrs)
            column_name = hdrs{j};
            prompt = sprintf('Load %s [Y/n]: ', column_name);
            str = input(prompt, 's');
            if ~isempty(str) && ~strcmp(str,'y') && ~strcmp(str,'Y')
            % mark header as removed
            hdrs{j} = strcat(column_name, '_x');
            % remove
            hdrs_rem(:,j-removed) = [];
            csvdats_rem(:,j-removed) = [];
            removed = removed + 1;
            end
        end
    elseif (dataType == 2)
        if (input('To transform data, press 1 \n if you have transformed data, press 0: '))
        transType = input('Press \n[1] log (+1) and scaling \n[2] arcsinh  \n[3] logicle: ');
            if (transType ==2)
            %CyTOF data transformation with arcsin
                csvdats = asinh(csvdats./5);
            elseif (transType == 3)
            %FACS data transformation with LOGICLE transformation
            %It takes into account minimum value of each channel
                parfor (p = 1:size(csvdats,2),feature('numCores'))
                    w = (4.5-log10(262144/abs(min(csvdats(:,p)))))/2;
                    if w < 0
                        obj = [LogicleTransform(262144,0.5,4.5,0)];
                        csvdats(:,p) = obj.transform(csvdats(:,p));
                    else 
                        obj = [LogicleTransform(262144,w,4.5,0)];
                        csvdats(:,p) = obj.transform(csvdats(:,p));
                    end
                end
            elseif (transType == 1)
                csvdats = log10(csvdats+1);
                scaleType = input('Press \n[1] for centering and scaling \n[2] only scaling usinf root-mean-square: ');
                if scaleType == 1
                    %line below is equivavelnt to R function: scale(data, center = T, scale = T))
                    csvdats = (csvdats - mean(csvdats,1))./std(csvdats,1);
                elseif scaleType == 2
                %Scale only by dividing values with root-mean-square equivavelnt to R function: scale(data, center = F, scale = T))
                    csvdats = csvdats./rms(csvdats,1);
                end
            end
        end
        csvdats_rem = csvdats;
        hdrs_rem=hdrs;    
    end
        sessionData = zeros(0, size(csvdats_rem, 2));
        gates = cell(numel(csvdats),4);
        disp(sprintf('Adding data to session ... %i',numel(csvdats)));

        [~, csvname, ~] = fileparts(files{i}); 

        %-- add data to giant matrix
        currInd = size(sessionData, 1);
        sessionData(currInd+1:currInd+size(csvdats_rem,1), 1:size(csvdats_rem,2)) = csvdats_rem(:, :);
        
        gates{i, 1} = char(csvname);
        gates{i, 2} = currInd+1:currInd+size(csvdats_rem,1);
        gates{i, 3} = hdrs_rem;
        gates{i, 4} = files{i}; % opt cell column to hold filename


%%%%%%%%%%% end of real script
end
disp 'Files loaded';

% for PCA on tspaces
numFirstW = size(hdrs_rem, 2) + 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Trajectory Algorithm Defaults
i = input('Select distance metric for tspace: [1]cosine (default), [2]euclidean, [3]mahalanobis : ');
if i == 3
    parameters.metric = 'mahalanobis';
elseif i == 2
    parameters.metric = 'euclidean';
else
    parameters.metric = 'cosine'; % default
end

parameters.k = input('Enter k number of neighbors (kNN): ');
if isempty(parameters.k)
    parameters.k = 20;
end

graph = input('Enter number of graphs: ');
if isempty(graph)
    graph = 5;
end

parameters.l = input('Enter l number of neighbors (l-kNN): ');
if isempty(parameters.l)
    parameters.l = 8;
end

parameters.num_landmarks = input('Enter number of landmarks : ');
if isempty(parameters.num_landmarks)
    parameters.num_landmarks = 10;
end
parameters.partial_order = [];

voting = input('choose a voting scheme from the following: [1]uniform, [2]exponential (preferred), [3]linear, [4]quadratic : ');
if voting == 4
    parameters.voting_scheme = 'quadratic';
elseif voting == 3
    parameters.voting_scheme = 'linear';
elseif voting == 1
    parameters.voting_scheme = 'uniform';
elseif voting == 2
    parameters.voting_scheme = 'exponential'; % default
end

% Landmarks are subsampled at equidistanced bands away from the start point.  
% Uses the points shortest path distance over the graph
parameters.band_sample = 1;

% Uses median 2 times
parameters.flock_landmarks = 2;

%Decide if you want to plot PCA embedding of tSPACE
plot = input('To plot tSPACE in PCA press 1 \n otherwise press 0: ');

% if 1 it will print messages, if 0 not.
parameters.verbose = 1;

%parameters.partial_order = []; % default is empty; Denis comment: in general this parameter is not used anywhere

parameters.deblur = 0;

% parameters.snn = input('enter number of shared nearest neighbors (default: 1) : ');
parameters.snn = 1;

% parameters.ann = false; % not used


% Searches for connected components if graph is discontious
parameters.search_connected_components = 1;

parameters.knn = []; % prebuilt on first run lNN graph

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

parameters.exclude_points = [];

parameters.gates = gates;
parameters.gate_index = 1;
parameters.gateContext = gates{1, 2};

hdrs_rem2 = hdrs_rem;


tspace_tsne = input('If you want to calculate tSNE using trajectories press [1], otherwise 0 :' );

%choose ground truth or # of kMeans populations

t_mode = input('For ground truth tSPACE press 1 \n For aproximate tSPACE press 0: ');
if (t_mode == 1)
    numPop = size(sessionData,1);
    clusters_trajectories = (1:1:size(sessionData,1))';
else c_mode = input('For Kmeans press 1 \n For SOM press 2: ');
    if (c_mode == 1)
        % do kmeans
        sprintf(strcat('Number of trajectories (Kmeans clusters) must be >=10 but <', num2str(size(sessionData,1)), ', (suggestion: 50 for initial runs)'));
        numPop = input('Input number of trajectories to calculate (10 or more); \n(recommendation: 20 for fast look, \n100-250 for accuracy), \npre-set 50: ');
        if isempty(numPop)
            numPop = 50;
        end
        rng(1); % For reproducibility
        clusters_trajectories = kmeans(sessionData, numPop, 'MaxIter', 10000); % 'Options', options);
    else 
        sprintf(strcat('Number of trajectories (number of SOM clusters) equals dim1 x dim2,\nplease choose dim1 & dim2 in following steps. \nNumber of total trajectories must be  >=10 but < ', num2str(size(sessionData,1))));
        
        dim1 = input('Input number of dimension1: ');
        dim2 = input('Input number of dimension2: ');
        numPop = dim1*dim2;
        rng(1);
        net = selforgmap([dim1 dim2]);
        net = train(net,sessionData');
        y = net(sessionData');
        clusters_trajectories = vec2ind(y)';
    end
end

%run PCA on sessionData
rng(1); % For reproducibility
if (size(hdrs_rem,2) >= 5)
    [pCoeff, pScore, pLatent, pTsquared, pExplained, pMu] = pca(sessionData,'NumComponents', 5);
else
    [pCoeff, pScore, pLatent, pTsquared, pExplained, pMu] = pca(sessionData,'NumComponents', size(hdrs_rem,2));
    pScore2 = zeros(size(sessionData,1),(5-size(hdrs_rem,2)));
    pScore = cat(2,pScore,pScore2);
    for i = size(hdrs_rem,2):5
        pExplained(i,1)=0;
    end
end

perplex = 50;
theta = 0.3;
rng(1); % For reproducibility
ptSNE = fast_tsne(sessionData, 30, perplex, theta);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Part that calls trajectory script.

    %separate cells by kMeans/SOM Population
    indexPops = zeros(numPop, numPop);
    pop = zeros(numPop, 1);
    for i = 1:size(clusters_trajectories,1)
        pop(clusters_trajectories(i)) = pop(clusters_trajectories(i)) + 1;
        indexPops(clusters_trajectories(i),pop(clusters_trajectories(i))) = i;
    end


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Build kNN graph
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % print parameters
if parameters.verbose
    parameters
    disp 'building kNN graph';
end

% Build kNN graph
    tic;
    knn = parfor_spdists_knngraph( sessionData, parameters.k,...
        'distance', parameters.metric,...
        'chunk_size', 1000,... % TODO: parameterize and add opt for ppl without PC toolbox
        'verbose', parameters.verbose );
    if parameters.verbose, fprintf('kNN computed: %gs\n', toc); end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Option 1: Check what does this option do to the data, try out with sythetic data   %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if (parameters.deblur)
        [i, j, s] = find(knn);
        % flock each data point to its knn median
        for ith=1:numel(i)
            data(ith, :) = median(data(j(i==ith), :)); 
        end
        if parameters.verbose, fprintf('re-computing kNN after data median filter\n'); tic; end
    	
        knn = parfor_spdists_knngraph( data, parameters.k, 'distance', parameters.metric, 'chunk_size', 1000, 'SNN', true, 'verbose', true);
        
        if parameters.verbose, fprintf('kNN re-computed after data median filter: %gs\n', toc); end
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Shared Nearest Neighbor
    if (parameters.snn~=0)
        if (parameters.verbose), fprintf('updating using jaccard...\n'); tic; end

        [j, i, s] = find(knn);
        % observational note: i is sorted with k-1 apearences each index
        % use this irreliable observation to make sn faster
        
        nData = size(sessionData,1);
        rem = cell(1, nData);

        tic;
        % for each point 1..n
        parfor ci=1:nData
            
            % grab neighbors            
            from = (ci-1)*parameters.k+1;
            to = ci*parameters.k;
            i_inds = from:to;
            i_neighs = j(i_inds);
            
            % for each neighbor
            for i_ind=i_inds
                i_neigh=j(i_ind);
                
                % grab the neighbor's neighbors
                from = (i_neigh-1)*parameters.k+1;
                to = i_neigh*parameters.k;
                j_neighs = j(from:to);
%                 j_neighs = j(i==i_neigh);
                
                % if the shared neighbors are not many enough
                if sum(ismember(i_neighs, j_neighs)) < parameters.snn
                    
                    % add them to remove list
                    rem{ci} = [rem{ci} i_ind];
                end
            end
        end

        rem = cell2mat(rem);

        % remove relevant indices
        i(rem) = [];
        j(rem) = [];
        s(rem) = [];
        knn = sparse(j, i, s);
    
        if parameters.verbose, fprintf('jaccard computed: %gs\n', toc); end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   knn = spdists_undirected( knn ); % TODO consider removing - outliers? \\ spdists_undirected is a separate function 
   parameters.knn = knn;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %
   
  parameters.search_connected_components = true; 
   tspacem = zeros(size(sessionData,1), numPop);
    
   graph_panel = cell(graph,1);
    
    
    for graph_iter = 1:graph
    
	    if (parameters.k~=parameters.l)
	        lknn = spdists_lknn( parameters.knn, parameters.l, parameters.verbose );
	    else
	        lknn = parameters.knn;
	    end
            
        parfor (i = 1:numPop, feature('numCores'))
            %start event
            s = indexPops(i,1);
            tspacem(:,i) = runpathFinder(sessionData, lknn, parameters, s);
        end
        
        graph_panel{graph_iter} = tspacem;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    tspacem = cat(3, graph_panel{:});
    tspacem = mean(tspacem,3);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %run pca on tspaces
    rng(1); % For reproducibility
    if (size(tspacem,2) >20)
        [tCoeff, tScore, tLatent, tTsquared, tExplained, tMu] = pca(tspacem,'NumComponents', 20);
        tExplain = round(tExplained, 2);
    elseif (size(tspacem,2) <= 20)
        [tCoeff, tScore, tLatent, tTsquared, tExplained, tMu] = pca(tspacem,'NumComponents', 10);
        tExplain = round(tExplained, 2);
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if(tspace_tsne == 1)
    perplex = 50;
    theta = 0.3;
    rng(1); % For reproducibility
    wtSNE = fast_tsne(tspacem, 30, perplex, theta);
    end
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  saving files old
 if (t_mode == 1)
    Clusters = 'sc';
 else
    Clusters = num2str(numPop);
 end
    
%creating headers for pPCA
hdrs_rem3 = cell(1,size(pScore,2)+1);
hdrs_rem3(1,1) = cellstr('Index');

j = 1;
for i = 2:(size(pScore,2)+1)
    pcaname = sprintf('pPC%d',j);
    pcaname = strcat(pcaname,'_',num2str(round(pExplained(i,1),2)));
    hdrs_rem3(1,i) = cellstr(pcaname);
    j = j+1;
end

%creating headers for ptSNE
	for i = 1:size(ptSNE,2)
    	ptsnename = sprintf('ptSNE%d',i);
    	hdr = cellstr(ptsnename);
    	hdrs_rem3 = horzcat(hdrs_rem3,hdr);
    end
    
    %Headrs for tSPACE matrix file
    traj_hdrs = [];
    for i = 1:numPop
     tname = sprintf('T_%d',i);
        hdr = cellstr(tname);
        traj_hdrs = horzcat(traj_hdrs, hdr);
    end
    
    %file with only tspacem matrix (trajectories matrix) or tSPACE
    fileName = matlab.lang.makeValidName(['tsp' datestr(clock, 'mmddyy_HHMM') '_tSPACE_'   parameters.metric 'K' num2str(parameters.k) 'L' num2str(parameters.l) 'G' num2str(graph) 'LM' num2str(parameters.num_landmarks) 'T' Clusters csvname]);
    fileName = strcat(fileName, '.csv');
   
    %manipulate headers
    fid = fopen(fileName, 'w');
    fprintf(fid, '%s,', traj_hdrs{1,1:end-1});
    fprintf(fid, '%s\n', traj_hdrs{1,end});
    fclose(fid);

    dlmwrite(fileName, tspacem, '-append');
    fprintf('your tSPACE Matrix is exported as csv file %s\n', fileName);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hdrs_rem3 = horzcat(hdrs_rem3,'Cluster');

for i = 1:size(tScore,2)
        pcaname = sprintf('tPC%d',i);
        pcaname = strcat(pcaname,'_', num2str(round(tExplained(i,1),2)));
        hdr = cellstr(pcaname);
        hdrs_rem3 = horzcat(hdrs_rem3, hdr);
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %file with allData (pca on sessionData, ptSNE, kMeans, pca on wanderlusts, wtSNE, wanderlustData)
    index = zeros(size(sessionData,1),1);
    for i = 1:size(sessionData,1)
        index(i,1) = i;
    end
    
        %If both Sample column and tSNE of trajectories exist
    if exist('Sample') && exist('wtSNE') %TESTED
        allData = cat(2,index,pScore, ptSNE, clusters_trajectories, tScore, wtSNE, csvdats, Sample);
        for i = 1:size(wtSNE,2)
            wtsnename = sprintf('wtSNE%d',i);
            hdr = cellstr(wtsnename);
            hdrs_rem3 = horzcat(hdrs_rem3,hdr);
        end
        hdrs_rem3 = horzcat(hdrs_rem3, hdrs);
        hdrs_rem3 = horzcat(hdrs_rem3, cellstr('Sample'));
       % hdrs_rem3 = horzcat(hdrs_rem3, hdrs_rem(:,numFirstW:size(tspacem,2)));
    
        %If Sample column exists and tSNE of trajectories does not
    elseif exist('Sample') ~ exist('wtSNE');  %TESTED
        
        allData = cat(2,index,pScore, ptSNE, clusters_trajectories, tScore, csvdats, Sample);
        hdrs_rem3 = horzcat(hdrs_rem3, hdrs);
        hdrs_rem3 = horzcat(hdrs_rem3, cellstr('Sample'));
       % hdrs_rem3 = horzcat(hdrs_rem3, hdrs_rem(:,numFirstW:size(tspacem,2)));
    
        %If neither Sample nor tSNE of trajectories exist 
    elseif ~exist('Sample') ~ exist('wtSNE'); %
        allData = cat(2,index,pScore, ptSNE, clusters_trajectories, tScore, csvdats);
        hdrs_rem3 = horzcat(hdrs_rem3, hdrs);
        
    
        %If Sample column does not exist and tSNE of trajectories exists
    else ~exist('Sample') && exist('wtSNE'); %TESTED
        allData = cat(2,index,pScore, ptSNE, clusters_trajectories, tScore, wtSNE, csvdats);
        for i = 1:size(wtSNE,2)
            wtsnename = sprintf('wtSNE%d',i);
            hdr = cellstr(wtsnename);
            hdrs_rem3 = horzcat(hdrs_rem3,hdr);
        end
        hdrs_rem3 = horzcat(hdrs_rem3, hdrs);
        
    end
    
    fileNameAll = matlab.lang.makeValidName([ 'ad' csvname   parameters.metric 'K' num2str(parameters.k) 'L' num2str(parameters.l) 'G' num2str(graph) 'LM' num2str(parameters.num_landmarks) 'T' num2str(numPop) ]);
    fileNameAll = strcat(fileNameAll, '.csv');
    fid = fopen(fileNameAll, 'w');
    fprintf(fid, '%s,', hdrs_rem3{1,1:end-1});
    fprintf(fid, '%s\n', hdrs_rem3{1,end});
    fclose(fid);

    dlmwrite(fileNameAll, allData,'-append');
    fprintf('PCA components of your Trajectory Space are exported as csv file %s\n', fileNameAll);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %file with megaMat (sessionData, kMeans, pca on wanderlusts)
    megaMat = cat(2,index, csvdats, clusters_trajectories, tScore);
    %hdr = cellstr('kMeans');
    hdrs_rem2 = horzcat( cellstr('Index'), hdrs, cellstr('Cluster'));
    for i = 1:size(tScore,2)
        pcaname = sprintf('PC%d',i);
        pcaname = strcat(pcaname,'_',num2str(round(tExplained(i,1),2)));
        hdr = cellstr(pcaname);
        hdrs_rem2 = horzcat(hdrs_rem2, hdr);
    end

    fileNamePCA = matlab.lang.makeValidName([ 'PCAs' csvname  parameters.metric 'K' num2str(parameters.k) 'L' num2str(parameters.l) 'G' num2str(graph) 'LM' num2str(parameters.num_landmarks) 'T' num2str(numPop) ]);
    fileNamePCA = strcat(fileNamePCA, '.csv');
    fid = fopen(fileNamePCA, 'w');
    fprintf(fid, '%s,', hdrs_rem2{1,1:end-1});
    fprintf(fid, '%s\n', hdrs_rem2{1,end});
    fclose(fid);

    dlmwrite(fileNamePCA, megaMat,'-append');
    fprintf('PCA components of your Trajectory Space are exported as csv file %s\n', fileNamePCA);
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Plotting PCAs
    scatter3(tScore(:,1), tScore(:,2), tScore(:,3),1,'k')

    plotName = matlab.lang.makeValidName(['TrajPCA' csvname  parameters.metric 'K' num2str(parameters.k) 'L' num2str(parameters.l) 'G' num2str(graph) 'LM' num2str(parameters.num_landmarks) 'T' num2str(numPop) ]);
    title (plotName);

    lx = xlabel(hdrs_rem3(1,10)); % x-axis label
    set(lx,'rotation',15);
    ly = ylabel(hdrs_rem3(1,11));  % y-axis label
    set(ly,'rotation',-25);
    zlabel(hdrs_rem3(1,12));  % z-axis label
    savefig(plotName);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   