function IDX=argprctile(arr, prc)
    IDX=find(arr==prctile(arr, prc));
end