function IDX=argmax(arr)
    IDX = find(arr==max(arr));
end