function ind = minind(x)
    [~, ind] = min(x);
end