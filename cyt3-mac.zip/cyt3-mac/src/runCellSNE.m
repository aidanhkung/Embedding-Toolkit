function runCellSNE(filename, idx_channels)

    [fcsdats fcshdrs]=fca_readfcs(filename);
    


end