function ind = maxind(x)
    [~, ind] = max(x);
end