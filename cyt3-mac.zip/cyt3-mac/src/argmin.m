function IDX=argmin(arr)
    IDX = find(arr==max(arr));
end